This folder contains video clips from an experiment on Minecraft.


2success&pointing_LR  (Gesture only condition)
This video shows two participants using the method of 'pointing' - staring at a location and jumping up and down.  The video is from player B's perspective.  In this case, player B points to an existing block to refer to colour, then to a location to instruct player A to place a block there.  After about 27 seconds, player B realises a mistake has been made and removes some blocks before continuing.


7frustration_LR 
This video shows some problems in communicaiton.  The video is from player B's perspective.  Player B wants player A to place a block on top of the black block in the middle of the screen.  The crosshair indicates where player B is looking.  Player B uses the 'pointing' gesture of jumping up and down, and must do so for quite a long time before player A responds.  Player A then places a block in the wrong position, forcing palyer B to remove it.  The removal is interpreted by A as a mistake in colour, not location, so A tries to fix the problem by replacing the block with a different colour.
Both of these players were inexperienced at playing Minecraft, which could have contributed to the difficulty in communiction.

1knocking_LR

This shows how one pair used the auditory channel to communicate.  The video is from player B's perspective.  Player B points to the location of the block (using a tapping gesture inside Minecraft).  Player B places a red block in this location.  Player A then uses the auditory communication channel (they knock twice on the table) before moving away from the area.   Player B follows A to a set of 'reference' blocks to one side of the building area.  Player A 'points' to a grey block by standing on it and jumping.  Player A uses the auditionary communication channel (they knock three times).  It seems like the knocking is being used to communicate about the sequential aspects of the task (as opposed to refering to objects in the world).  They use the auditory channel to indicate affirmation or or to indicate that they should move on to the next thing.


3Repair_LR.m4v
This video comes from the fastest pair and shows some complicated sequences, including repair.  They were allowed to use knocking, but never did.  In this sequence, some confusion occurs about which colour of block should be placed, and the players spend some time correcting this.  Before placing the next block, player A requests confirmation of the block colour by pointing to a set of  'reference blocks' that the players placed beside the main structure.  All this is done with pointing and gesture.  The video is from Player A's perspective. 

Both players make use of 'tapping', which involves striking a block, but not long enough to break it.  This appears as a crack appearing briefly where the player struck the block, drawing attention to it.

Player B taps on one of the white reference blocks and then on a location in the structure (i.e. "put a white block here").  Player A removes a brown block and replaces it with a white block, then looks towards A for the next step.  Player B taps on the recently placed white block, intending to mean that another block should be placed on top (according to the plan), but A interprets this as the last action being a mistake, so removes the block and replaces it with a brown block. 
Player A immediately looks towards B, who shakes their head.  A removes the block and looks towards B, who taps on the ground.  A places a brown block, and looks towards B again, who shakes their head.  A removes the block and replaces it with a white block. 
B now taps on a block in the structure, indicating that a block should be placed on top of the previously placed block.  Player A now initiates a kind of repair sequence: Player A requests confirmation of which block should be placed by tapping one of the reference blocks.  Player B confirms that a white block should be placed by tapping the same reference block. Player A places a white block.